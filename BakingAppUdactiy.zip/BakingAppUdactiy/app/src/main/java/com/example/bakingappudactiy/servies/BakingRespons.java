package com.example.bakingappudactiy.servies;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class BakingRespons {

    @SerializedName("id")
    private int mId ;
    @SerializedName("name")
    private String mName;

    @SerializedName("ingredients")
    private List<Ingredients> mIngredients;

    @SerializedName("steps")
    private List<StepsBaking> mSteps;


    @SerializedName("servings")
    private int mServing;


    @SerializedName("image")
    private String mImage;


    public int getmId() {
        return mId;
    }

    public void setmId(int mId) {
        this.mId = mId;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public List<Ingredients> getmIngredients() {
        return mIngredients;
    }

    public void setmIngredients(List<Ingredients> mIngredients) {
        this.mIngredients = mIngredients;
    }

    public List<StepsBaking> getmSteps() {
        return mSteps;
    }

    public void setmSteps(List<StepsBaking> mSteps) {
        this.mSteps = mSteps;
    }

    public int getmServing() {
        return mServing;
    }

    public void setmServing(int mServing) {
        this.mServing = mServing;
    }

    public String getmImage() {
        return mImage;
    }

    public void setmImage(String mImage) {
        this.mImage = mImage;
    }
}
