package com.example.bakingappudactiy.servies;

import com.google.gson.annotations.SerializedName;

public class Ingredients {



    @SerializedName("quantity")
    private int mQuantity;
    @SerializedName("measure")
    private  String mMeasure;
    @SerializedName("ingredient")
    private String mingredient;


    public int getmQuantity() {
        return mQuantity;
    }

    public void setmQuantity(int mQuantity) {
        this.mQuantity = mQuantity;
    }

    public String getmMeasure() {
        return mMeasure;
    }

    public void setmMeasure(String mMeasure) {
        this.mMeasure = mMeasure;
    }

    public String getMingredient() {
        return mingredient;
    }

    public void setMingredient(String mingredient) {
        this.mingredient = mingredient;
    }








}
