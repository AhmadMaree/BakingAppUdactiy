package com.example.bakingappudactiy.servies;

import com.google.gson.annotations.SerializedName;

public  class StepsBaking {


    @SerializedName("id")
    private int mId;
    @SerializedName("shortDescription")
    private String mShortDescription;

    @SerializedName("description")
    private String mDescription;

    @SerializedName("videoURL")
    private String mVideoURl;

    @SerializedName("thumbnailURL")
    private String mThumbnailURL;


    public int getmId() {
        return mId;
    }

    public void setmId(int mId) {
        this.mId = mId;
    }

    public String getmShortDescription() {
        return mShortDescription;
    }

    public void setmShortDescription(String mShortDescription) {
        this.mShortDescription = mShortDescription;
    }

    public String getmDescription() {
        return mDescription;
    }

    public void setmDescription(String mDescription) {
        this.mDescription = mDescription;
    }

    public String getmVideoURl() {
        return mVideoURl;
    }

    public void setmVideoURl(String mVideoURl) {
        this.mVideoURl = mVideoURl;
    }

    public String getmThumbnailURL() {
        return mThumbnailURL;
    }

    public void setmThumbnailURL(String mThumbnailURL) {
        this.mThumbnailURL = mThumbnailURL;
    }
}
